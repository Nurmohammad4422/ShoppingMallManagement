-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema shoppingmall
--

CREATE DATABASE IF NOT EXISTS shoppingmall;
USE shoppingmall;

--
-- Definition of table `employeedetails`
--

DROP TABLE IF EXISTS `employeedetails`;
CREATE TABLE `employeedetails` (
  `employeeid` int(10) unsigned NOT NULL auto_increment,
  `ename` varchar(45) NOT NULL,
  `eaddress` varchar(100) NOT NULL,
  `egender` varchar(45) NOT NULL,
  `ephoneno` varchar(45) NOT NULL,
  `edob` date NOT NULL,
  `equalification` varchar(45) NOT NULL,
  `ejoiningdate` date NOT NULL,
  `esalary` varchar(45) NOT NULL,
  `epost` varchar(45) NOT NULL,
  `eemail` varchar(100) NOT NULL,
  `efathername` varchar(45) NOT NULL,
  `emothername` varchar(45) NOT NULL,
  PRIMARY KEY  (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeedetails`
--

/*!40000 ALTER TABLE `employeedetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `employeedetails` ENABLE KEYS */;


--
-- Definition of table `employeespayment`
--

DROP TABLE IF EXISTS `employeespayment`;
CREATE TABLE `employeespayment` (
  `emppayid` int(10) unsigned NOT NULL auto_increment,
  `employeeid` int(10) unsigned NOT NULL,
  `emppaysalary` varchar(45) NOT NULL,
  `salpaiddate` date NOT NULL,
  `salpaidformonth` varchar(45) NOT NULL,
  `salpaidforyear` varchar(45) NOT NULL,
  PRIMARY KEY  (`emppayid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeespayment`
--

/*!40000 ALTER TABLE `employeespayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `employeespayment` ENABLE KEYS */;


--
-- Definition of table `expense`
--

DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense` (
  `expenseid` int(10) unsigned NOT NULL auto_increment,
  `expdescription` varchar(250) NOT NULL,
  `expamount` varchar(45) NOT NULL,
  `expdate` date NOT NULL,
  `expmonth` varchar(45) NOT NULL,
  `expyear` varchar(45) NOT NULL,
  PRIMARY KEY  (`expenseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;


--
-- Definition of table `mallinfo`
--

DROP TABLE IF EXISTS `mallinfo`;
CREATE TABLE `mallinfo` (
  `mallid` int(10) unsigned NOT NULL auto_increment,
  `mallname` varchar(45) NOT NULL,
  `malladdress` varchar(250) NOT NULL,
  `mallphone` varchar(45) NOT NULL,
  `malltax` varchar(45) NOT NULL,
  `malldescription` varchar(250) NOT NULL,
  `mallwebsite` varchar(45) NOT NULL,
  PRIMARY KEY  (`mallid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mallinfo`
--

/*!40000 ALTER TABLE `mallinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `mallinfo` ENABLE KEYS */;


--
-- Definition of table `rentcollection`
--

DROP TABLE IF EXISTS `rentcollection`;
CREATE TABLE `rentcollection` (
  `rentcollid` int(10) unsigned NOT NULL auto_increment,
  `shopid` int(10) unsigned NOT NULL,
  `tenentid` int(10) unsigned NOT NULL,
  `rentamount` varchar(45) NOT NULL,
  `rentformonth` varchar(45) NOT NULL,
  `rentforyear` varchar(45) NOT NULL,
  `rentpaiddate` date NOT NULL,
  PRIMARY KEY  (`rentcollid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rentcollection`
--

/*!40000 ALTER TABLE `rentcollection` DISABLE KEYS */;
/*!40000 ALTER TABLE `rentcollection` ENABLE KEYS */;


--
-- Definition of table `shopdetails`
--

DROP TABLE IF EXISTS `shopdetails`;
CREATE TABLE `shopdetails` (
  `shopid` int(10) unsigned NOT NULL auto_increment,
  `shopno` varchar(45) NOT NULL,
  `floorno` varchar(45) NOT NULL,
  `blockno` varchar(45) NOT NULL,
  `shopdescription` varchar(45) NOT NULL,
  `shopstatus` varchar(45) NOT NULL,
  `rentpermonth` varchar(45) NOT NULL,
  `securityamount` varchar(45) NOT NULL,
  PRIMARY KEY  (`shopid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopdetails`
--

/*!40000 ALTER TABLE `shopdetails` DISABLE KEYS */;
INSERT INTO `shopdetails` (`shopid`,`shopno`,`floorno`,`blockno`,`shopdescription`,`shopstatus`,`rentpermonth`,`securityamount`) VALUES 
 (1,'101','1st','A','dfdshfkh','Occupaid','10000','200000'),
 (2,'102','1st','A','dfdshfkh','Occupaid','12000','200000');
/*!40000 ALTER TABLE `shopdetails` ENABLE KEYS */;


--
-- Definition of table `tenantdetails`
--

DROP TABLE IF EXISTS `tenantdetails`;
CREATE TABLE `tenantdetails` (
  `tenantid` int(10) unsigned NOT NULL auto_increment,
  `tname` varchar(45) NOT NULL,
  `taddress` varchar(100) NOT NULL,
  `tphoneno` varchar(45) NOT NULL,
  `shopid` int(10) unsigned NOT NULL,
  `rentedshopname` varchar(45) NOT NULL,
  `rentedshopdate` date NOT NULL,
  `rentstatus` varchar(45) NOT NULL,
  PRIMARY KEY  USING BTREE (`tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenantdetails`
--

/*!40000 ALTER TABLE `tenantdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenantdetails` ENABLE KEYS */;


--
-- Definition of table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `emailid` varchar(100) NOT NULL,
  `username` varchar(45) NOT NULL,
  `udob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  PRIMARY KEY  (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` (`emailid`,`username`,`udob`,`address`,`phone`,`gender`) VALUES 
 ('fdfgu@hjf.com','nur','1994-03-21','Dhaka','5676575473','male'),
 ('nuru@hjf.com','Asique','1994-03-21','Dhaka','5676575473','male');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `emailid` varchar(100) NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY  (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` (`emailid`,`password`,`role`,`status`) VALUES 
 ('admin@cv.com','123','ADMIN-USER','t'),
 ('dj@dfls.com','123','ROLE-USER','t'),
 ('mfgj@cv.com','123','ADMIN-USER','f');
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
