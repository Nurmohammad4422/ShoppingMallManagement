
package com.nur.shoppingmall.service;

import com.nur.shoppingmall.model.Shopdetails;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface ShopdetailsService {
 List<Shopdetails> findAllShopdetails();
    Shopdetails saveShopdetails(Shopdetails sd);
    Shopdetails findShopdetailsById(Integer id);
    void updateShopdetails(Shopdetails sd);     
    void deleteShopdetailsById(Integer id);   
}
