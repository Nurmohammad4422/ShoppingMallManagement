
package com.nur.shoppingmall.service;

import com.nur.shoppingmall.model.Tenantdetails;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface TenantDetailsService {
List<Tenantdetails> findAllTenantdetails();
    Tenantdetails saveTenantdetails(Tenantdetails td);
    Tenantdetails findTenantdetailsById(Integer id);
    void updateTenantdetails(Tenantdetails td);     
    void deleteTenantdetailsById(Integer id);       
}
