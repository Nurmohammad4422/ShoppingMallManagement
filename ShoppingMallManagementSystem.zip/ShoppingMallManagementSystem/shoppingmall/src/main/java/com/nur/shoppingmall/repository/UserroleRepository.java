
package com.nur.shoppingmall.repository;

import com.nur.shoppingmall.model.Userrole;
import com.nur.shoppingmall.service.UserroleService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class UserroleRepository implements UserroleService{
    @Autowired
    SessionFactory sessionFactory;
    
      @Override
    public List<Userrole> findAllUserrole() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Userrole> UserroleList = s.createQuery("from Userrole").list();
        t.commit();
        s.close();
        return UserroleList;
    }

    @Override
    public Userrole saveUserrole(Userrole sd) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(sd);
        t.commit();
        s.close();
        return sd;
    }

    @Override
    public Userrole findUserroleById(String id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userrole sd = (Userrole) s.get(Userrole.class, id);
        t.commit();
        s.close();
        return sd;
    }

    @Override
    public void updateUserrole(Userrole sd) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.update(sd);
        t.commit();
        s.close();
    }

    @Override
    public void deleteUserroleById(String id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userrole sd = (Userrole) s.get(Userrole.class, id);
        s.delete(sd);
        t.commit();
        s.close();

    }
    
}
