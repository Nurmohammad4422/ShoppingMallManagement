package com.nur.shoppingmall.model;
// Generated Mar 9, 2020 4:24:46 PM by Hibernate Tools 4.3.1

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Tenantdetails implements Serializable {

    @Id
    private Integer tenantid;
    @Column
    private String tname;
    @Column
    private String taddress;
    @Column
    private String tphoneno;
    @Column
    private int shopid;
    @Column
    private String rentedshopname;
    @Column
    @Temporal(TemporalType.DATE)
    private Date rentedshopdate;
    @Column
    private String rentstatus;

    public Integer getTenantid() {
        return this.tenantid;
    }

    public void setTenantid(Integer tenantid) {
        this.tenantid = tenantid;
    }

    public String getTname() {
        return this.tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTaddress() {
        return this.taddress;
    }

    public void setTaddress(String taddress) {
        this.taddress = taddress;
    }

    public String getTphoneno() {
        return this.tphoneno;
    }

    public void setTphoneno(String tphoneno) {
        this.tphoneno = tphoneno;
    }

    public int getShopid() {
        return this.shopid;
    }

    public void setShopid(int shopid) {
        this.shopid = shopid;
    }

    public String getRentedshopname() {
        return this.rentedshopname;
    }

    public void setRentedshopname(String rentedshopname) {
        this.rentedshopname = rentedshopname;
    }

    public Date getRentedshopdate() {
        return this.rentedshopdate;
    }

    public void setRentedshopdate(Date rentedshopdate) {
        this.rentedshopdate = rentedshopdate;
    }

    public String getRentstatus() {
        return this.rentstatus;
    }

    public void setRentstatus(String rentstatus) {
        this.rentstatus = rentstatus;
    }

}
