/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nur.shoppingmall.repository;

import com.nur.shoppingmall.model.Userinfo;
import com.nur.shoppingmall.service.UserinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Core J2EE R-41
 */
@Repository
public class UserinfoRepository implements UserinfoService{
    @Autowired
    SessionFactory sessionFactory;
    
    @Override
    public Userinfo insertUserinfo(Userinfo ui) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(ui);
        t.commit();
        s.close();
        return ui;
    }

    @Override
    public void updateUserinfo(Userinfo ui) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.update(ui);
        t.commit();
        s.close();
    }

    @Override
    public void deleteUserinfo(String id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userinfo ui = (Userinfo) s.get(Userinfo.class, id);
        s.delete(ui);
        t.commit();
        s.close();
    }

    @Override
    public List<Userinfo> viewUserinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Userinfo> userinfoList = s.createQuery("from Userinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return userinfoList;
    }

    @Override
    public Userinfo viewOneUserinfo(String id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userinfo ui = (Userinfo) s.get(Userinfo.class, id);
        t.commit();
        s.close();
        return ui;
    }
    
}
