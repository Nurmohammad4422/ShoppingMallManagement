
package com.nur.shoppingmall.service;

import com.nur.shoppingmall.model.Userrole;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface UserroleService {
  List<Userrole> findAllUserrole();
    Userrole saveUserrole(Userrole ur);
    Userrole findUserroleById(String id);
    void updateUserrole(Userrole ur);     
    void deleteUserroleById(String id);      
}
