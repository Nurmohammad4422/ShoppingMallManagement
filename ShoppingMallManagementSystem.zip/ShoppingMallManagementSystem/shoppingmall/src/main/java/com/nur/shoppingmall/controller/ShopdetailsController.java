package com.nur.shoppingmall.controller;

import com.nur.shoppingmall.model.Shopdetails;
import com.nur.shoppingmall.service.ShopdetailsService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1")
public class ShopdetailsController {

    @Autowired
    private ShopdetailsService shopdetailsService;

    @GetMapping("/shopdetails")
    public List<Shopdetails> getAllShopdetails() {
        return shopdetailsService.findAllShopdetails();
    }

    @PostMapping("/shopdetails")
    public Shopdetails createShopdetails(@RequestBody Shopdetails shopdetails) {
        return shopdetailsService.saveShopdetails(shopdetails);
    }

    @GetMapping("/shopdetails/{id}")
    public ResponseEntity<Shopdetails> getUser(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Shopdetails shopdetails = shopdetailsService.findShopdetailsById(id);
        if (shopdetails == null) {
            System.out.println("Shopdetails with id " + id + " not found");
            return new ResponseEntity<Shopdetails>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Shopdetails>(shopdetails, HttpStatus.OK);
    }

    @PutMapping("/shopdetails/{id}")
    public ResponseEntity<Shopdetails> updateUser(@PathVariable("id") Integer id, @RequestBody Shopdetails shopdetails) {
        System.out.println("Updating Shopdetails " + id);
        Shopdetails currentShopdetails = shopdetailsService.findShopdetailsById(id);

        if (currentShopdetails == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Shopdetails>(HttpStatus.NOT_FOUND);
        }

        currentShopdetails.setShopid(shopdetails.getShopid());
        currentShopdetails.setShopno(shopdetails.getShopno());
        currentShopdetails.setFloorno(shopdetails.getFloorno());
        currentShopdetails.setBlockno(shopdetails.getBlockno());
        currentShopdetails.setShopdescription(shopdetails.getShopdescription());
        currentShopdetails.setShopstatus(shopdetails.getShopstatus());
        currentShopdetails.setRentpermonth(shopdetails.getRentpermonth());
        currentShopdetails.setSecurityamount(shopdetails.getSecurityamount());
        shopdetailsService.updateShopdetails(currentShopdetails);
        return new ResponseEntity<Shopdetails>(currentShopdetails, HttpStatus.OK);
    }

    @DeleteMapping("/shopdetails/{id}")
    public ResponseEntity<Shopdetails> deleteUser(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Shopdetails with id " + id);

        Shopdetails shopdetails = shopdetailsService.findShopdetailsById(id);
        if (shopdetails == null) {
            System.out.println("Unable to delete. Shopdetails with id " + id + " not found");
            return new ResponseEntity<Shopdetails>(HttpStatus.NOT_FOUND);
        }

        shopdetailsService.deleteShopdetailsById(id);
        return new ResponseEntity<Shopdetails>(HttpStatus.NO_CONTENT);
    }
}
