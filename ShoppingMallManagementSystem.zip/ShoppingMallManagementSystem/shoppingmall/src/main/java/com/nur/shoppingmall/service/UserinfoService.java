/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nur.shoppingmall.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.nur.shoppingmall.model.Userinfo;
/**
 *
 * @author C13
 */
@Service
public interface UserinfoService {

 public Userinfo  insertUserinfo(Userinfo ui);

    public void updateUserinfo(Userinfo ui);

    public void deleteUserinfo(String id);

    public List<Userinfo> viewUserinfo();

    public Userinfo viewOneUserinfo(String id);    
}
