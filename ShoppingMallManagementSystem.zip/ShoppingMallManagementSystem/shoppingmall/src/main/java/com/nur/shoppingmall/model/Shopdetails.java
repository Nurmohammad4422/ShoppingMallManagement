package com.nur.shoppingmall.model;
// Generated Mar 7, 2020 6:26:04 PM by Hibernate Tools 4.3.1

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Shopdetails implements Serializable {

    @Id
    private Integer shopid;
    @Column
    private String shopno;
    @Column
    private String floorno;
    @Column
    private String blockno;
    @Column
    private String shopdescription;
    @Column
    private String shopstatus;
    @Column
    private String rentpermonth;
    @Column
    private String securityamount;

    public Integer getShopid() {
        return this.shopid;
    }

    public void setShopid(Integer shopid) {
        this.shopid = shopid;
    }

    public String getShopno() {
        return this.shopno;
    }

    public void setShopno(String shopno) {
        this.shopno = shopno;
    }

    public String getFloorno() {
        return this.floorno;
    }

    public void setFloorno(String floorno) {
        this.floorno = floorno;
    }

    public String getBlockno() {
        return this.blockno;
    }

    public void setBlockno(String blockno) {
        this.blockno = blockno;
    }

    public String getShopdescription() {
        return this.shopdescription;
    }

    public void setShopdescription(String shopdescription) {
        this.shopdescription = shopdescription;
    }

    public String getShopstatus() {
        return this.shopstatus;
    }

    public void setShopstatus(String shopstatus) {
        this.shopstatus = shopstatus;
    }

    public String getRentpermonth() {
        return this.rentpermonth;
    }

    public void setRentpermonth(String rentpermonth) {
        this.rentpermonth = rentpermonth;
    }

    public String getSecurityamount() {
        return this.securityamount;
    }

    public void setSecurityamount(String securityamount) {
        this.securityamount = securityamount;
    }

}
