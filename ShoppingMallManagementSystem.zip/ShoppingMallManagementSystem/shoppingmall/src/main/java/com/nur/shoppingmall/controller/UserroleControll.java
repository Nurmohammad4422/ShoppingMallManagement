
package com.nur.shoppingmall.controller;

import com.nur.shoppingmall.model.Userrole;
import com.nur.shoppingmall.service.UserroleService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1")
public class UserroleControll {
 @Autowired
    private UserroleService shopdetailsService;

    @GetMapping("/shopdetails")
    public List<Userrole> getAllUserrole() {
        return shopdetailsService.findAllUserrole();
    }

    @PostMapping("/shopdetails")
    public Userrole createUserrole(@RequestBody Userrole shopdetails) {
        return shopdetailsService.saveUserrole(shopdetails);
    }

    @GetMapping("/shopdetails/{id}")
    public ResponseEntity<Userrole> getUser(@PathVariable("id") String id) {
        System.out.println("Fetching User with id " + id);
        Userrole shopdetails = shopdetailsService.findUserroleById(id);
        if (shopdetails == null) {
            System.out.println("Userrole with id " + id + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Userrole>(shopdetails, HttpStatus.OK);
    }

    @PutMapping("/shopdetails/{id}")
    public ResponseEntity<Userrole> updateUser(@PathVariable("id") String id, @RequestBody Userrole shopdetails) {
        System.out.println("Updating Userrole " + id);
        Userrole currentUserrole = shopdetailsService.findUserroleById(id);

        if (currentUserrole == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }

        currentUserrole.setEmailid(shopdetails.getEmailid());
        currentUserrole.setPassword(shopdetails.getPassword());
        currentUserrole.setRole(shopdetails.getRole());
        currentUserrole.setStatus(shopdetails.getStatus());
        shopdetailsService.updateUserrole(currentUserrole);
        return new ResponseEntity<Userrole>(currentUserrole, HttpStatus.OK);
    }

    @DeleteMapping("/shopdetails/{id}")
    public ResponseEntity<Userrole> deleteUser(@PathVariable("id") String id) {
        System.out.println("Fetching & Deleting Userrole with id " + id);

        Userrole shopdetails = shopdetailsService.findUserroleById(id);
        if (shopdetails == null) {
            System.out.println("Unable to delete. Userrole with id " + id + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }

        shopdetailsService.deleteUserroleById(id);
        return new ResponseEntity<Userrole>(HttpStatus.NO_CONTENT);
    }   
}
