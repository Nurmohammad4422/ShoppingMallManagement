/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nur.shoppingmall.repository;

import com.nur.shoppingmall.model.Shopdetails;
import com.nur.shoppingmall.service.ShopdetailsService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ShopdetailsRepository  implements ShopdetailsService{
 @Autowired
 SessionFactory sessionFactory;   

    @Override
    public List<Shopdetails> findAllShopdetails() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Shopdetails> shopdetailsList = s.createQuery("from Shopdetails").list();
        t.commit();
        s.close();
        return shopdetailsList;
    }

    @Override
    public Shopdetails saveShopdetails(Shopdetails sd) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(sd);
        t.commit();
        s.close();
        return sd;
    }

    @Override
    public Shopdetails findShopdetailsById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Shopdetails sd = (Shopdetails) s.get(Shopdetails.class, id);
        t.commit();
        s.close();
        return sd;
    }

    @Override
    public void updateShopdetails(Shopdetails sd) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.update(sd);
        t.commit();
        s.close();
    }

    @Override
    public void deleteShopdetailsById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Shopdetails sd = (Shopdetails) s.get(Shopdetails.class, id);
        s.delete(sd);
        t.commit();
        s.close();

    }   
}
